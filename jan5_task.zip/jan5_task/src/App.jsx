import React from 'react'
import Navbar from './components/navbar/Navbar'

const App = () => {
  return (
    <div>
      <Navbar/>
    </div>
  )
}

export default App