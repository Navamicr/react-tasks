import ReactDOM from "react-dom/client";
import './styles.css'

import ParentComponent from "./ParentComponent";
ReactDOM.createRoot(document.getElementById('root')).render(<ParentComponent/>)