import React from 'react'
import { useState } from 'react'

const App = () => {
    let[companies,Setcomp]=useState([{
        company_id:1,
        company_name:"AMAZON",
        company_type:"Product Based",
        company_employees:30000,
        company_opening:true
    },{
        company_id:2,
        company_name:"TCS",
        company_type:"Service Based",
        company_employees:10000,
        company_opening:false
    },{
        company_id:3,
        company_name:"GOOGLE",
        company_type:"Product Based",
        company_employees:50000,
        company_opening:true
    },{
        company_id:4,
        company_name:"SOTI",
        company_type:"Product Based",
        company_employees:20000,
        company_opening:false
    },{
        company_id:4,
        company_name:"INFOSYS",
        company_type:"Service Based",
        company_employees:60000,
        company_opening:false
    }
])
  return (
    
    <div className='main-container'>
       {
        companies.map((company)=>{
            return(
                company.company_opening ? (
                    <div>
                      <div className='open' key={company.id}>
                           <h3>{company.company_name}</h3>
                           <p className='type'>{company.company_type}</p>
                           <p className='emp'>No.of Employees: {company.company_employees}</p>

                      </div>
                    </div>
                 ):(
                    <div>
                     <div className='close' key={company.id}>
                           <h3>{company.company_name}</h3>
                           <p className='type'>{company.company_type}</p>
                           <p className='emp'>No.of Employees: {company.company_employees}</p>
                     </div>
         
                    </div>
                 )
            )
        })
        
       }
    </div>
    
  )
}

export default App